package com.example.vcutkitleindeksi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class sonuc extends AppCompatActivity {
        public TextView txtyazı;
        @Override
        protected void onCreate (Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_sonuc);

            txtyazı=findViewById(R.id.sonucsayısı);

            Intent intent = getIntent();
            String yazı =intent.getStringExtra("sonuc");
            txtyazı.setText(yazı);




        }
    }
