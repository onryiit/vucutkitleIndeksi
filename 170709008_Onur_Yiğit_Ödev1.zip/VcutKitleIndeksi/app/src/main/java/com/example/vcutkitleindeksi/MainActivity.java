package com.example.vcutkitleindeksi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public EditText txtboy;
    public EditText txtkilo;
    public Button btnhesapla;
    public TextView txtsonucText;
    public TextView txtdeger;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtboy = findViewById(R.id.EditBoy);
        txtkilo = findViewById(R.id.EditKilo);
        btnhesapla = findViewById(R.id.Hesapla);



        btnhesapla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double boy = Double.parseDouble(txtboy.getText().toString());
                double kilo = Double.parseDouble(txtkilo.getText().toString());
                double txtsonuc =(kilo / Math.pow((boy/100),2));

                String sonucyazısı ="";

                if (txtsonuc < 20.7) {
                    sonucyazısı=("Zayıf,ideal kilonun altında");
                    Intent intent =new Intent(getApplicationContext(), sonuc.class);
                    intent.putExtra("sonuc",sonucyazısı.toString());
                    startActivity(intent);
                } else if (txtsonuc >= 20.7 && txtsonuc < 26.4) {
                    sonucyazısı=("Normal,ideal kilo");
                    Intent intent =new Intent(getApplicationContext(), sonuc.class);
                    intent.putExtra("sonuc",sonucyazısı.toString());
                    startActivity(intent);
                } else if (txtsonuc >= 26.5 && txtsonuc < 27.8) {
                    sonucyazısı=("Hafif şişman,");
                    Intent intent =new Intent(getApplicationContext(), sonuc.class);
                    intent.putExtra("sonuc",sonucyazısı.toString());
                    startActivity(intent);
                } else if (txtsonuc >= 27.9 && txtsonuc < 31.1) {
                    sonucyazısı=("şişman,");
                    Intent intent =new Intent(getApplicationContext(), sonuc.class);
                    intent.putExtra("sonuc",sonucyazısı.toString());
                    startActivity(intent);
                } else if (txtsonuc >= 31.2 && txtsonuc < 44.8) {
                    sonucyazısı=("Obez");
                    Intent intent =new Intent(getApplicationContext(), sonuc.class);
                    intent.putExtra("sonuc",sonucyazısı.toString());
                    startActivity(intent);
                } else if (txtsonuc >= 44.9){
                    sonucyazısı=("Aşırı obez, Riskli");
                    Intent intent =new Intent(getApplicationContext(), sonuc.class);
                    intent.putExtra("sonuc",sonucyazısı.toString());
                    startActivity(intent);
                }
            }
        });
    }
}

